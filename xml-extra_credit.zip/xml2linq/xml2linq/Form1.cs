﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;// linq object used
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;//windows form created
using System.Xml;
using System.Xml.Linq;//xml to linq
/*
Extra Credit (50pts)
XML & XLS to LINQ objects and displaying the document properly. 
Use a Windows Form or ASP.NET rather than the console.
Objectives:
    XML & XLS
    LINQ
    windows forms OR asp .net
*/
namespace xml2linq
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();//create windows form
            XElement student = XElement.Load("george.xml");//load xml document
            IEnumerable <string> courses = //build linq query
                from item in student.Descendants("class")
                select (string)item.Element("title");
            foreach (var s in courses)
            {//output requested data
                listBox1.Items.Add(s.ToString());
            }
        }
    }
}
