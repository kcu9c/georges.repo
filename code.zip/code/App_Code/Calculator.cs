﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Calculator
/// </summary>
public class Calculator
{
  public double Add(double a, double b)
  {
    return a + b;
  }

  public double Subtract(double a, double b)
  {
    return a - b;
  }

  public double Multiply(double a, double b)
  {
    return a * b;
  }

  public double Divide(double a, double b)
  {
    return a / b;
  }

  public Calculator()
  {
    //
    // TODO: Add constructor logic here
    //
  }
}