﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PlanetWroxModel;

public partial class _ManagePhotoAlbum : BasePage
{
  protected void Page_Load(object sender, EventArgs e)
  {

  }

  protected void EntityDataSource1_Inserting(object sender, EntityDataSourceChangingEventArgs e)
  {// convert string to int for identification of which photo album
    int photoAlbumId = Convert.ToInt32(Request.QueryString.Get("PhotoAlbumId"));
    Picture myPicture = (Picture)e.Entity; /*type cast passed EntityDataSourceChangingEventArgs
    object as Picture object*/
    myPicture.PhotoAlbumId = photoAlbumId;
    //assign converted ID to Picture object
    FileUpload FileUpload1 = (FileUpload)ListView1.InsertItem.FindControl("FileUpload1");
    //retrieve name of picture upload
    string virtualFolder = "~/GigPics/";//set up pathing for physical copy of upload
    string physicalFolder = Server.MapPath(virtualFolder);
    string fileName = Guid.NewGuid().ToString();
    string extension = System.IO.Path.GetExtension(FileUpload1.FileName);
    FileUpload1.SaveAs(System.IO.Path.Combine(physicalFolder, fileName + extension));
    myPicture.ImageUrl = virtualFolder + fileName + extension;//put absolute location of media into object
  }

  protected void ListView1_ItemInserting(object sender, ListViewInsertEventArgs e)
  {// populate list control
    FileUpload FileUpload1 = (FileUpload)ListView1.InsertItem.FindControl("FileUpload1");
    if (!FileUpload1.HasFile || !FileUpload1.FileName.ToLower().EndsWith(".jpg"))
    {// with valid images
      CustomValidator cusValImage = (CustomValidator)ListView1.InsertItem.FindControl("cusValImage");
      cusValImage.IsValid = false;
      e.Cancel = true;
    }
  }
}
